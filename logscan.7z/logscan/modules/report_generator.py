import pandas
import json
import logging

def create_report(results, output_path, output_format):                                         # Создаем функцию для создания отчетов
    try:                                                                                        # начало блока исключений
        if output_format == 'csv':                                                              # Проверяем csv        
            create = pandas.DataFrame(results)                                                  # Создаем DataFrame из данных
            create.to_csv(output_path, index=False)                                             # Сохраняем DataFrame в CSV файл по указанному пути, не включая индекс.
            logging.info(f'[+] Report successfully created in CSV format at {output_format}')   # Логгирование на успех 
        elif output_format == 'json':                                                           # Проверяем формат json
            with open(output_path, 'w') as f:                                                   # Открываем файл по указанному пути
                for result in results:                                                          # Прлоходим по каждому элементу в списке
                    if isinstance(result['result'], set):                                       # Проверяем, является ли значение 'result' множеством (set)
                        result['result'] = list(result['result'])                               # Преобразуем множество в список, чтобы его можно было сериализовать в JSON
                json.dump(results, f, indent=4)                                                 # Записываем список результатов в файл в формате JSON
            logging.info(f'[+] Successully created in JSON format at {output_format}')          # Логгирование на успех
    except Exception as e:                                                                      # Обработка ошибок
        logging.error(f'[-] Erroe: {e}')                                                        # Логгирование с выводом ошибки