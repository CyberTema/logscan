import re 
import logging
def parse_log(log_file):                                                                        # Создаем фукцию для вывода IP и Hash из лог файла
    ip_cut = r'\d+\.\d+\.\d+\.\d+'                                                              # Вырезем IP 
    hash_cut = r'SHA256: ([a-fA-F0-9]{64})|hash: ([a-fA-F0-9]{64})|MD5: ([a-fA-F0-9]{32})'      # Вырезем все виды алгоритмов шифрования
    tuples = []                                                                                 # Создаем лист, чтобы потом записывать туда результаты вывода
    try:                                                                                        # начало блока исключений                                                    
        with open(log_file, 'r') as f:                                                          # Открываем для чтение лог-файла
            for line in f:
                ip_data = re.findall(ip_cut,line)                                               # Выводим IP в переменную
                hash_data = re.findall(hash_cut,line)                                           # Выводим Hash в переменную
                for ip in ip_data:                                                              # Цикл для записи IP в файл tuple 
                    tuples.append({'type':'ip','value':ip})                                     # Добавляем записи IP в tuple
                for hash in hash_data:                                                          # Цикл для записи Hash в файл tuple
                    tuples.append({'type':'hash','value': hash[0] or hash[1] or hash[2]})       # Добавляем записи Hash в tuple
        logging.info(f'[+] Extracted {len(tuples)} IP and Hash from the log-file.')             # Логгируем на успех
    except FileNotFoundError:                                                                   # Обработка ошибок
        logging.error(f'[-] Log-file not found: {log_file}')                                    # Логгирование, указанный лог-файл не найден
    except Exception as e:                                                                      # Обработка ошибок
        logging.error(f'[-] Error reading log-file: {e}')                                       # Логгирование, проблема в чтении лог-файла
    return tuples            

