import requests
import logging

def check_threat(tuples, api_key=None):    # Создаем функцию по проверки лог-файлов в VirusTotal
    results = []                           # Создаем список, чтобы потом добавить в него результат проверки
    for tuple in tuples:                   # цикл для вывода данных (value) для проверки в VirusTotal
        result = {
            'value': tuple['value'],
            'type': tuple['type'],
            'result': {},
            'date': None
        }
        if api_key:                                                                                                                     # Проверка данных 
            try:                                                                                                                        # начало блока исключений
                response = requests.get(f'https://www.virustotal.com/api/v3/files/{tuple['value']}', headers = { 'x-apikey': api_key})  # Отправляем запрос по каждой value в VirusTotal 
                if response.status_code == 200:                                                                                         # Если статус будет положительный (200) пойдет дальше по условию
                    data = response.json()                                                                                              # Присваем переменной ответ в формате json
                    result['result'] = data.get('data', {}).get('attributes', {}).get('last_analysis_stats', {})                        # Извлекаем результаты проверки, если их нет, то возвращает пустой словарь
                    result['date'] = data.get('data', {}).get('attributes', {}).get('last_analysis_stats', None )                       #  --||--||--
                    logging.info(f'[+] Successfully received data for {tuple['value']}')                                                # Логгируем, выходит сообщение об успехе 
                else:
                    logging.warning(f'[-] Data for {tuple['value']} is not found')                                                      # Логгируем, сообщение о неудаче, данные не найдены
                    result['result'] = {'error, no data available'}                                                                     # В результате записываем, что данные недоступны
            except Exception as e:                                                                                                      # Обработка ошибок
                logging.error(f'Error: {e}')                                                                                            # Логгирование об ошибке
                result['result'] = {'[-] error': f'API error: {response.status_code()}'}                                                # Выводо об этом в результат
        else:
            logging.warning('[-] API is not found')                                                                                     # Логгирование, предупрежение    
        results.append(result)  
            
    
    return results        
