#logscan

logscan — это CLI-утилита для автоматизации анализа лог-файлов и проверки потенциальных угроз через API VirusTotal. 
Утилита извлекает IP-адреса и SHA256-хэши из логов, проверяет их на наличие угроз и генерирует отчеты в формате CSV или JSON.
Утилита использует модуль `logging` для записи событий, ошибок и статусов. Логи сохраняются в консоль и могут быть перенаправлены в файл.
Аргументы

--log-file`: Путь к лог-файлу (обязательный).
--api-key`: Ключ API для VirusTotal (обязательный).
--output`: Путь к файлу отчета (обязательный).
--format`: Формат отчета (csv или json) (обязательный).

## Инструкцией по установке и запуску

1) Установка записимостей 
cd <директория>

python -m venv <название вашего окружения>

<название вашего окружения>\Scripts\activate

pip install -r requirements.txt

pip list (для проверки корректности установки модулей)

<название вашего окружения>\Scripts\deactivate.bat

2) Запуск
Открываем cmd и прописываем команду для запуска как в примере.

Пример запуска для csv формата:
python main.py --log-file sample.log --api-key <ваш_api_key> --output report.csv --format csv

Пример запуска для json формата:
python main.py --log-file sample.log --api-key <ваш_api_key> --output report.json --format json


Пример лог-файла sample.log:

2026-03-14 08:12:11 [INFO] User login successful from IP: 10.0.0.45
2026-03-14 08:12:12 [WARN] Failed authentication attempt from 172.16.254.23
2026-03-14 08:12:13 [INFO] User logout completed for user: admin
2026-03-14 08:12:14 [ERROR] File integrity check failed - SHA256: 9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08
2026-03-14 08:12:15 [INFO] Database backup completed - checksum: 7d793037a0760186574b0282f2f435e7b0a1c8c2d6c5a2a9e3c4b5d6f7a8b9c0
2026-03-14 08:12:16 [DEBUG] DNS query to 9.9.9.9
2026-03-14 08:12:17 [ERROR] Suspicious activity detected from IP: 203.0.113.77
2026-03-14 08:12:18 [INFO] File upload: report_2026.xlsx, hash: a54d88e06612d820bc3be72877c74f257b561b19f3f4c1d6a2c3e4f5b6a7c8d9
2026-03-14 08:12:19 [SECURITY] Malware detected: MD5: 5d41402abc4b2a76b9719d911017c592, SHA256: 2cf24dba5fb0a030e0d7c9bdb5a1f3c6a6a39aea66e68132c0aaf645ed90e299
2026-03-14 08:12:20 [INFO] System hash: b94d27b9934d3e08a52e52d7da7dabfade4f3e1a4f0e8f5d2a3c4b5d6e7f8a9b
2026-03-14 08:12:21 [WARN] Invalid hash format: abc123xyz


Пример отчета csv:

value,type,result,date
10.0.0.45,ip,"{'error, no data available'}",
172.16.254.23,ip,"{'error, no data available'}",
9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08,hash,"{'malicious': 0, 'suspicious': 0, 'undetected': 62, 'harmless': 0, 'timeout': 0, 'confirmed-timeout': 0, 'failure': 0, 'type-unsupported': 14}","{'malicious': 0, 'suspicious': 0, 'undetected': 62, 'harmless': 0, 'timeout': 0, 'confirmed-timeout': 0, 'failure': 0, 'type-unsupported': 14}"
9.9.9.9,ip,"{'error, no data available'}",
203.0.113.77,ip,"{'error, no data available'}",
a54d88e06612d820bc3be72877c74f257b561b19f3f4c1d6a2c3e4f5b6a7c8d9,hash,"{'error, no data available'}",
5d41402abc4b2a76b9719d911017c592,hash,"{'malicious': 0, 'suspicious': 0, 'undetected': 62, 'harmless': 0, 'timeout': 0, 'confirmed-timeout': 0, 'failure': 0, 'type-unsupported': 14}","{'malicious': 0, 'suspicious': 0, 'undetected': 62, 'harmless': 0, 'timeout': 0, 'confirmed-timeout': 0, 'failure': 0, 'type-unsupported': 14}"
2cf24dba5fb0a030e0d7c9bdb5a1f3c6a6a39aea66e68132c0aaf645ed90e299,hash,"{'error, no data available'}",
b94d27b9934d3e08a52e52d7da7dabfade4f3e1a4f0e8f5d2a3c4b5d6e7f8a9b,hash,"{'error, no data available'}",

Пример отчета json:

[
    {
        "value": "10.0.0.45",
        "type": "ip",
        "result": [
            "error, no data available"
        ],
        "date": null
    },
    {
        "value": "172.16.254.23",
        "type": "ip",
        "result": [
            "error, no data available"
        ],
        "date": null
    },
    {
        "value": "9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08",
        "type": "hash",
        "result": {
            "malicious": 0,
            "suspicious": 0,
            "undetected": 62,
            "harmless": 0,
            "timeout": 0,
            "confirmed-timeout": 0,
            "failure": 0,
            "type-unsupported": 14
        },
        "date": {
            "malicious": 0,
            "suspicious": 0,
            "undetected": 62,
            "harmless": 0,
            "timeout": 0,
            "confirmed-timeout": 0,
            "failure": 0,
            "type-unsupported": 14
        }
    },
    {
        "value": "9.9.9.9",
        "type": "ip",
        "result": [
            "error, no data available"
        ],
        "date": null
    },
    {
        "value": "203.0.113.77",
        "type": "ip",
        "result": [
            "error, no data available"
        ],
        "date": null
    },
    {
        "value": "a54d88e06612d820bc3be72877c74f257b561b19f3f4c1d6a2c3e4f5b6a7c8d9",
        "type": "hash",
        "result": [
            "error, no data available"
        ],
        "date": null
    },
    {
        "value": "5d41402abc4b2a76b9719d911017c592",
        "type": "hash",
        "result": {
            "malicious": 0,
            "suspicious": 0,
            "undetected": 62,
            "harmless": 0,
            "timeout": 0,
            "confirmed-timeout": 0,
            "failure": 0,
            "type-unsupported": 14
        },
        "date": {
            "malicious": 0,
            "suspicious": 0,
            "undetected": 62,
            "harmless": 0,
            "timeout": 0,
            "confirmed-timeout": 0,
            "failure": 0,
            "type-unsupported": 14
        }
    },
    {
        "value": "2cf24dba5fb0a030e0d7c9bdb5a1f3c6a6a39aea66e68132c0aaf645ed90e299",
        "type": "hash",
        "result": [
            "error, no data available"
        ],
        "date": null
    },
    {
        "value": "b94d27b9934d3e08a52e52d7da7dabfade4f3e1a4f0e8f5d2a3c4b5d6e7f8a9b",
        "type": "hash",
        "result": [
            "error, no data available"
        ],
        "date": null
    }
]




