import argparse
import logging
from modules.log_parser import parse_log
from modules.virustotal import check_threat
from modules.report_generator import create_report

def main():                                                                                         # Создаем главную функцию
    parser = argparse.ArgumentParser(description='Log File Scaner')                                 # Создаем объект для обработки аргуметом
    parser.add_argument('--log-file', required=True, help='Path to the log file')                   # Создаем аргумент --log-file для указания пути до лог-файла
    parser.add_argument('--api-key', required=True, help='VirusTotal API-key')                      # Создаем аргумент --api-key для ключа от VirusTotal
    parser.add_argument('--output', required=True, help='Path to the output report file')           # Создаем аргумент --output для вывода результата проверки VirusTotal
    parser.add_argument('--format', choices=['json','csv'], help='Output format (.json or .csv)')   # Создаем аргумент --format для указания вормата с выбором json или csv

    args = parser.parse_args()                                                                      # Парсим аргументы командной строки

    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')     # Конфиг для логгирования

    logging.info('[+] Start logscan...')                                                            # Логгирование о старте утилиты 
    try:
        tuples = parse_log(args.log_file)                                                           # Выводим результат в переменную из функции по обработке лог-файлов

        results = check_threat(tuples, args.api_key)                                                # Вызываем функцию для проверки в VirusTotal

        create_report(results, args.output,args.format)                                             # Вызываем фунцию для вывода отчета
    except Exception as e:                                                                          # Обработки ошибок
        logging.error(f'[-] Error: {e}')                                                            # Логгирование ошибки
if __name__ == '__main__':
    main()    